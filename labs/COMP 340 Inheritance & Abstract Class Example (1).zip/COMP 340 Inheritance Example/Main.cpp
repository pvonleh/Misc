#include "Dog.hpp"
#include <iostream>

int main() {
	Dog* myDog = new Dog(5, "Duke");
	std::cout << myDog->GetName() << "\t" << myDog->GetAge() << std::endl;
	myDog->Speak();

	//Animal* myDog2 = new Dog(6, "Sparky");
	//Will not work because GetName() is not defined in Animal
	//std::cout << myDog2->GetName() << "\t" << myDog2->GetAge() << std::endl;

	//Will not work because Animal is an abstract class
	Animal* myAnimal = new Animal(8);
}

