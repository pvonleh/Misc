#include "Animal.hpp"

Animal::Animal(int age){
	this->age = age;
}

int Animal::GetAge(){
	return this->age;
}