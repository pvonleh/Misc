#include "Dog.hpp"

Dog::Dog(int age, std::string name) : Animal(age){
	this->name = name;
}

std::string Dog::GetName(){
	return this->name;
}

void Dog::Speak(){
	std::cout<<"Woof!"<<std::endl;
}