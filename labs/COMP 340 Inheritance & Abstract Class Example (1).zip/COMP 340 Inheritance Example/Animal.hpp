#include <iostream>
//#include <string>
class Animal {

public:
	Animal(int age);
	int GetAge();
	//Defines a pure virtual function
	//This makes the function Abstract, which forces all subclasses to implement it or also be Abstract
	virtual void Speak() = 0;
	//virtual std::string GetName() = 0;

protected:
	int age;
};
