#include "Animal.hpp"
#include <string>

class Dog : public Animal {

private:
	std::string name;
public:
	Dog(int age, std::string name);
	std::string GetName();
	void Speak();
};
