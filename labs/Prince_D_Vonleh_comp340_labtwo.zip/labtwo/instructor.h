#ifndef INSTRUCTOR_H
#define INSTRUCTOR_H

#include <iostream>
#include <string>
#include "person.h"

using namespace std;
class Instructor : Person
{
public:
    Instructor(string name, string emailAddress, string employeeID);
    string GetEmployeeID();
    string GetName();
    string GetEmailAddress();

private:
    string employeeID;
};

#endif // INSTRUCTOR_H
