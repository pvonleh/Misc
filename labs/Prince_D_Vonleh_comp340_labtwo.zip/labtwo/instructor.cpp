#include "instructor.h"


Instructor::Instructor(string name, string emailAddress, string employeeID){
    this->name = name;
    this->emailAddress = emailAddress;
    this->employeeID = employeeID;
}
string Instructor::GetEmployeeID(){
    return this->employeeID;
}
string Instructor::GetName()
{
    return this->name;
}
string Instructor::GetEmailAddress()
{
    return this->emailAddress;
}
