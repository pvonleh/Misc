#include "Player.hpp"

Player::Player(std::string name, int health, int damage){
	this->name = name;
	this->health = health;
	this->damage = damage;
}

int Player::GetHealth() {
	return this->health;
}

int Player::GetDamage() {
	return this->damage;
}

void Player::AddItemToInventory(Item* item){
	this->inventory.push_back(item);
}

void Player::ModifyHealth(int amount){
	this->health -= amount;
}

void Player::DealDamage(CombatUnit* target){
	std::cout<<this->name<<" attacks!"<<std::endl;
	target->ModifyHealth(this->damage);
}

void Player::UseItem(Item* item, CombatUnit* target){
	std::cout<<this->name<<" uses "<<item->GetName()<<std::endl;
	item->Effect(target);
}

void Player::PrintStats(){
	std::cout<<this->name<<"'s health: "<<this->health<<"\tDamage: "<<this->damage<<std::endl<<std::endl;
}