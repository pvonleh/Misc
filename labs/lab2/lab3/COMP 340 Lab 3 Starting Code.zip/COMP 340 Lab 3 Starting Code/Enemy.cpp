#include "Enemy.hpp"

Enemy::Enemy(int health, int damage, std::string type) {
	this->health = health;
	this->damage = damage;
	this->type = type;
}

int Enemy::GetHealth() {
	return this->health;
}

int Enemy::GetDamage() {
	return this->damage;
}

void Enemy::ModifyHealth(int amount){
	this->health -= amount;
}

void Enemy::DealDamage(CombatUnit* target){
	std::cout<<this->type<<" attacks!"<<std::endl;
	target->ModifyHealth(this->damage);
}

void Enemy::UseItem(Item* item, CombatUnit* target){
	std::cout<<this->type<<" uses "<<item->GetName()<<std::endl;
	item->Effect(target);
}

void Enemy::PrintStats(){
	std::cout<<this->type<<"'s health: "<<this->health<<"\tDamage: "<<this->damage<<std::endl;
}