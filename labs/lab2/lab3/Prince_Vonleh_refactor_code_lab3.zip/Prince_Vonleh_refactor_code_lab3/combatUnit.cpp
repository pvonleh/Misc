#include "combatUnit.hpp"
#include <string>
using std::string;

CombatUnit::CombatUnit(string name, int health, int damage)
{


}